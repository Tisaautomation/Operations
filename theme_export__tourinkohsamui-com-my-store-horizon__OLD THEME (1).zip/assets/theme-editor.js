/**
 * Tour In Koh Samui - Theme JavaScript
 * Handles mobile menu, carousel functionality, and header scroll effects
 */

(function() {
  'use strict';

  // ===========================
  // Header Scroll Effect
  // ===========================
  function initHeaderScroll() {
    const header = document.getElementById('siteHeader');
    if (!header) return;

    let lastScrollTop = 0;
    const scrollThreshold = 50;

    window.addEventListener('scroll', function() {
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      
      if (scrollTop > scrollThreshold) {
        header.classList.add('scrolled');
      } else {
        header.classList.remove('scrolled');
      }

      lastScrollTop = scrollTop;
    });
  }

 // ===========================
// Mobile Menu Toggle - OPTIMIZED
// ===========================
/* Optimization: Minimal DOM queries, efficient event delegation */
function initMobileMenu() {
  const menuToggle = document.getElementById('mobileMenuToggle');
  const mainNav = document.getElementById('mainNav');
  
  if (!menuToggle || !mainNav) {
    console.error('Mobile menu elements not found!');
    return;
  }
  
  console.log('Mobile menu initialized'); // Debug log
  
  // Toggle menu function
  const toggleMenu = (forceClose = false) => {
    const isActive = forceClose ? false : !mainNav.classList.contains('active');
    
    if (isActive) {
      mainNav.classList.add('active');
      menuToggle.classList.add('active');
      document.body.style.overflow = 'hidden';
    } else {
      mainNav.classList.remove('active');
      menuToggle.classList.remove('active');
      document.body.style.overflow = '';
    }
    
    menuToggle.setAttribute('aria-expanded', isActive);
    console.log('Menu toggled:', isActive); // Debug log
  };
  
  // Remove any existing listeners (prevent double-binding)
  const newMenuToggle = menuToggle.cloneNode(true);
  menuToggle.parentNode.replaceChild(newMenuToggle, menuToggle);
  
  // Hamburger click - single unified handler
  newMenuToggle.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    console.log('Burger clicked!'); // Debug log
    toggleMenu();
  }, { passive: false });
  
  // Close on overlay click
  mainNav.addEventListener('click', (e) => {
    if (e.target === mainNav) toggleMenu(true);
  });
  
  // Close on Escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && mainNav.classList.contains('active')) {
      toggleMenu(true);
    }
  });
  
  // Close on resize to desktop
  let resizeTimer;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
      if (window.innerWidth > 768) toggleMenu(true);
    }, 150);
  });
  
  // Mobile dropdown toggle
  const dropdowns = mainNav.querySelectorAll('.has-dropdown > .nav-link');
  // Inject small chevron button for clear toggle
dropdowns.forEach(link => {
  if (link.querySelector('.dropdown-toggle')) return;

  const btn = document.createElement('span');
  btn.className = 'dropdown-toggle';
  btn.setAttribute('aria-hidden', 'true');
  btn.innerHTML = '▾';
  btn.style.marginLeft = '6px';
  link.appendChild(btn);
});

  dropdowns.forEach(link => {
    link.addEventListener('click', (e) => {
      if (window.innerWidth <= 768) {
        e.preventDefault();
        const parent = link.parentElement;
        
        // Close other dropdowns
        mainNav.querySelectorAll('.has-dropdown.active').forEach(item => {
          if (item !== parent) item.classList.remove('active');
        });
        
        // Toggle current
        parent.classList.toggle('active');
      }
    });
  });
}

  // ===========================
  // Product Carousel
  // ===========================
  function initCarousels() {
    const carousels = document.querySelectorAll('[data-carousel]');
    
    carousels.forEach(function(carousel) {
      const track = carousel.querySelector('.carousel-track');
      const prevBtn = carousel.closest('.carousel-wrapper').querySelector('.carousel-arrow--prev');
      const nextBtn = carousel.closest('.carousel-wrapper').querySelector('.carousel-arrow--next');
      
      if (!track || !prevBtn || !nextBtn) return;

      const cards = track.querySelectorAll('.product-card');
      if (cards.length === 0) return;

      let currentIndex = 0;
      const cardWidth = cards[0].offsetWidth;
      const gap = 32; // 2rem gap between cards
      const visibleCards = getVisibleCards();

      function getVisibleCards() {
        const containerWidth = carousel.offsetWidth;
        return Math.floor(containerWidth / (cardWidth + gap));
      }

      function updateCarousel() {
        const maxIndex = Math.max(0, cards.length - visibleCards);
        currentIndex = Math.max(0, Math.min(currentIndex, maxIndex));
        
        const offset = currentIndex * (cardWidth + gap);
        track.style.transform = `translateX(-${offset}px)`;

        // Update button states
        prevBtn.style.opacity = currentIndex === 0 ? '0.5' : '1';
        prevBtn.style.cursor = currentIndex === 0 ? 'not-allowed' : 'pointer';
        
        nextBtn.style.opacity = currentIndex >= maxIndex ? '0.5' : '1';
        nextBtn.style.cursor = currentIndex >= maxIndex ? 'not-allowed' : 'pointer';
      }

      prevBtn.addEventListener('click', function() {
        if (currentIndex > 0) {
          currentIndex--;
          updateCarousel();
        }
      });

      nextBtn.addEventListener('click', function() {
        const maxIndex = Math.max(0, cards.length - visibleCards);
        if (currentIndex < maxIndex) {
          currentIndex++;
          updateCarousel();
        }
      });

      // Touch/Swipe support for mobile
      let touchStartX = 0;
      let touchEndX = 0;

      carousel.addEventListener('touchstart', function(e) {
        touchStartX = e.changedTouches[0].screenX;
      });

      carousel.addEventListener('touchend', function(e) {
        touchEndX = e.changedTouches[0].screenX;
        handleSwipe();
      });

      function handleSwipe() {
        const swipeThreshold = 50;
        const diff = touchStartX - touchEndX;

        if (Math.abs(diff) > swipeThreshold) {
          if (diff > 0) {
            // Swipe left - next
            const maxIndex = Math.max(0, cards.length - visibleCards);
            if (currentIndex < maxIndex) {
              currentIndex++;
              updateCarousel();
            }
          } else {
            // Swipe right - prev
            if (currentIndex > 0) {
              currentIndex--;
              updateCarousel();
            }
          }
        }
      }

      // Update on window resize
      window.addEventListener('resize', function() {
        updateCarousel();
      });

      // Initial update
      updateCarousel();
    });
  }

  // ===========================
  // Dropdown Menu Accessibility
  // ===========================
  function initDropdowns() {
    const dropdownItems = document.querySelectorAll('.has-dropdown');
    
    dropdownItems.forEach(function(item) {
      const link = item.querySelector('.nav-link');
      
      
    });
    
    // Reset dropdowns on resize
    window.addEventListener('resize', function() {
      if (window.innerWidth > 768) {
        dropdownItems.forEach(function(item) {
          item.classList.remove('active');
        });
      }
    });
  }

  // ===========================
  // Smooth Scroll for Anchor Links
  // ===========================
  function initSmoothScroll() {
    const links = document.querySelectorAll('a[href^="#"]');
    
    links.forEach(function(link) {
      link.addEventListener('click', function(e) {
        const href = this.getAttribute('href');
        if (href === '#' || href === '') return;
        
        const target = document.querySelector(href);
        if (target) {
          e.preventDefault();
          const headerHeight = document.getElementById('siteHeader').offsetHeight;
          const targetPosition = target.getBoundingClientRect().top + window.pageYOffset - headerHeight;
          
          window.scrollTo({
            top: targetPosition,
            behavior: 'smooth'
          });
        }
      });
    });
  }

  // ===========================
  // Lazy Load Images
  // ===========================
  function initLazyLoad() {
    if ('IntersectionObserver' in window) {
      const images = document.querySelectorAll('img[loading="lazy"]');
      
      const imageObserver = new IntersectionObserver(function(entries, observer) {
        entries.forEach(function(entry) {
          if (entry.isIntersecting) {
            const img = entry.target;
            img.src = img.dataset.src || img.src;
            img.classList.add('loaded');
            observer.unobserve(img);
          }
        });
      });

      images.forEach(function(img) {
        imageObserver.observe(img);
      });
    }
  }

  // ===========================
  // Initialize Everything on DOM Ready
  // ===========================
  function init() {
    initHeaderScroll();
    initMobileMenu();
    initCarousels();
    initDropdowns();
    initSmoothScroll();
    initLazyLoad();
  }

  // Run when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Expose init function for theme editor
  window.themeInit = init;

})();