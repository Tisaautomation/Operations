/**
 * Tour In Koh Samui - Theme JavaScript
 * Handles mobile menu, carousel functionality, and header scroll effects
 */

(function() {
  'use strict';

  // ===========================
  // Header Scroll Effect
  // ===========================
  function initHeaderScroll() {
    const header = document.getElementById('siteHeader');
    if (!header) return;

    let lastScrollTop = 0;
    const scrollThreshold = 50;

    window.addEventListener('scroll', function() {
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      
      if (scrollTop > scrollThreshold) {
        header.classList.add('scrolled');
      } else {
        header.classList.remove('scrolled');
      }

      lastScrollTop = scrollTop;
    });
  }

  // ===========================
  // Mobile Menu Toggle
  // ===========================
  function initMobileMenu() {
    const menuToggle = document.getElementById('mobileMenuToggle');
    const mainNav = document.getElementById('mainNav');
    
    if (!menuToggle || !mainNav) return;

    menuToggle.addEventListener('click', function() {
      mainNav.classList.toggle('active');
      menuToggle.classList.toggle('active');
      
      // Prevent body scroll when menu is open
      if (mainNav.classList.contains('active')) {
        document.body.style.overflow = 'hidden';
      } else {
        document.body.style.overflow = '';
      }
    });

    // Close menu when clicking outside
    document.addEventListener('click', function(e) {
      if (!mainNav.contains(e.target) && !menuToggle.contains(e.target)) {
        mainNav.classList.remove('active');
        menuToggle.classList.remove('active');
        document.body.style.overflow = '';
      }
    });

    // Close menu on window resize if going to desktop
    window.addEventListener('resize', function() {
      if (window.innerWidth > 768) {
        mainNav.classList.remove('active');
        menuToggle.classList.remove('active');
        document.body.style.overflow = '';
      }
    });
  }

  // ===========================
  // Product Carousel
  // ===========================
  function initCarousels() {
    const carousels = document.querySelectorAll('[data-carousel]');
    
    carousels.forEach(function(carousel) {
      const track = carousel.querySelector('.carousel-track');
      const prevBtn = carousel.closest('.carousel-wrapper').querySelector('.carousel-arrow--prev');
      const nextBtn = carousel.closest('.carousel-wrapper').querySelector('.carousel-arrow--next');
      
      if (!track || !prevBtn || !nextBtn) return;

      const cards = track.querySelectorAll('.product-card');
      if (cards.length === 0) return;

      let currentIndex = 0;
      const cardWidth = cards[0].offsetWidth;
      const gap = 32; // 2rem gap between cards
      const visibleCards = getVisibleCards();

      function getVisibleCards() {
        const containerWidth = carousel.offsetWidth;
        return Math.floor(containerWidth / (cardWidth + gap));
      }

      function updateCarousel() {
        const maxIndex = Math.max(0, cards.length - visibleCards);
        currentIndex = Math.max(0, Math.min(currentIndex, maxIndex));
        
        const offset = currentIndex * (cardWidth + gap);
        track.style.transform = `translateX(-${offset}px)`;

        // Update button states
        prevBtn.style.opacity = currentIndex === 0 ? '0.5' : '1';
        prevBtn.style.cursor = currentIndex === 0 ? 'not-allowed' : 'pointer';
        
        nextBtn.style.opacity = currentIndex >= maxIndex ? '0.5' : '1';
        nextBtn.style.cursor = currentIndex >= maxIndex ? 'not-allowed' : 'pointer';
      }

      prevBtn.addEventListener('click', function() {
        if (currentIndex > 0) {
          currentIndex--;
          updateCarousel();
        }
      });

      nextBtn.addEventListener('click', function() {
        const maxIndex = Math.max(0, cards.length - visibleCards);
        if (currentIndex < maxIndex) {
          currentIndex++;
          updateCarousel();
        }
      });

      // Touch/Swipe support for mobile
      let touchStartX = 0;
      let touchEndX = 0;

      carousel.addEventListener('touchstart', function(e) {
        touchStartX = e.changedTouches[0].screenX;
      });

      carousel.addEventListener('touchend', function(e) {
        touchEndX = e.changedTouches[0].screenX;
        handleSwipe();
      });

      function handleSwipe() {
        const swipeThreshold = 50;
        const diff = touchStartX - touchEndX;

        if (Math.abs(diff) > swipeThreshold) {
          if (diff > 0) {
            // Swipe left - next
            const maxIndex = Math.max(0, cards.length - visibleCards);
            if (currentIndex < maxIndex) {
              currentIndex++;
              updateCarousel();
            }
          } else {
            // Swipe right - prev
            if (currentIndex > 0) {
              currentIndex--;
              updateCarousel();
            }
          }
        }
      }

      // Update on window resize
      window.addEventListener('resize', function() {
        updateCarousel();
      });

      // Initial update
      updateCarousel();
    });
  }

  // ===========================
  // Dropdown Menu Accessibility
  // ===========================
  function initDropdowns() {
    const dropdownItems = document.querySelectorAll('.has-dropdown');
    
    dropdownItems.forEach(function(item) {
      const link = item.querySelector('.nav-link');
      
      // Toggle dropdown on mobile click
      if (window.innerWidth <= 768) {
        link.addEventListener('click', function(e) {
          e.preventDefault();
          item.classList.toggle('active');
          
          const dropdown = item.querySelector('.dropdown-menu');
          if (dropdown) {
            dropdown.style.display = item.classList.contains('active') ? 'block' : 'none';
          }
        });
      }
    });
  }

  // ===========================
  // Smooth Scroll for Anchor Links
  // ===========================
  function initSmoothScroll() {
    const links = document.querySelectorAll('a[href^="#"]');
    
    links.forEach(function(link) {
      link.addEventListener('click', function(e) {
        const href = this.getAttribute('href');
        if (href === '#' || href === '') return;
        
        const target = document.querySelector(href);
        if (target) {
          e.preventDefault();
          const headerHeight = document.getElementById('siteHeader').offsetHeight;
          const targetPosition = target.getBoundingClientRect().top + window.pageYOffset - headerHeight;
          
          window.scrollTo({
            top: targetPosition,
            behavior: 'smooth'
          });
        }
      });
    });
  }

  // ===========================
  // Lazy Load Images
  // ===========================
  function initLazyLoad() {
    if ('IntersectionObserver' in window) {
      const images = document.querySelectorAll('img[loading="lazy"]');
      
      const imageObserver = new IntersectionObserver(function(entries, observer) {
        entries.forEach(function(entry) {
          if (entry.isIntersecting) {
            const img = entry.target;
            img.src = img.dataset.src || img.src;
            img.classList.add('loaded');
            observer.unobserve(img);
          }
        });
      });

      images.forEach(function(img) {
        imageObserver.observe(img);
      });
    }
  }

  // ===========================
  // Initialize Everything on DOM Ready
  // ===========================
  function init() {
    initHeaderScroll();
    initMobileMenu();
    initCarousels();
    initDropdowns();
    initSmoothScroll();
    initLazyLoad();
  }

  // Run when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Expose init function for theme editor
  window.themeInit = init;

})();
