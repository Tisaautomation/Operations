import { Component } from '@theme/component';
import { onAnimationEnd } from '@theme/utilities';
import { ThemeEvents, CartUpdateEvent } from '@theme/events';

/**
 * A custom element that displays a cart icon with smooth animations.
 *
 * @typedef {object} Refs
 * @property {HTMLElement} cartBubble - The cart bubble element.
 * @property {HTMLElement} cartBubbleText - The cart bubble text element.
 * @property {HTMLElement} cartBubbleCount - The cart bubble count element.
 *
 * @extends {Component<Refs>}
 */
class CartIcon extends Component {
  requiredRefs = ['cartBubble', 'cartBubbleText', 'cartBubbleCount'];

  /** @type {number} */
  get currentCartCount() {
    return parseInt(this.refs.cartBubbleCount.textContent ?? '0', 10);
  }

  set currentCartCount(value) {
    this.refs.cartBubbleCount.textContent = value < 100 ? String(value) : '99+';
  }

  connectedCallback() {
    super.connectedCallback();
    document.addEventListener(ThemeEvents.cartUpdate, this.onCartUpdate);
    this.ensureCartBubbleIsCorrect();
    this.initializeAccessibility();
  }

  disconnectedCallback() {
    super.disconnectedCallback();
    document.removeEventListener(ThemeEvents.cartUpdate, this.onCartUpdate);
  }

  /**
   * Handles the cart update event.
   * @param {CartUpdateEvent} event - The cart update event.
   */
  onCartUpdate = async (event) => {
    const itemCount = event.detail.data?.itemCount ?? 0;
    const comingFromProductForm = event.detail.data?.source === 'product-form-component';
    await this.renderCartBubble(itemCount, comingFromProductForm);
    this.announceCartUpdate(itemCount, comingFromProductForm);
  };

  /**
   * Renders the cart bubble with smooth animations.
   * @param {number} itemCount - The number of items in the cart.
   * @param {boolean} comingFromProductForm - Whether the cart update is coming from the product form.
   * @param {boolean} animate - Whether to animate the cart bubble.
   */
  renderCartBubble = async (itemCount, comingFromProductForm, animate = true) => {
    // Toggle visibility classes
    this.refs.cartBubbleCount.classList.toggle('hidden', itemCount === 0);
    this.refs.cartBubble.classList.toggle('visually-hidden', itemCount === 0);
    
    // Add animation class if needed
    if (animate && itemCount > 0) {
      this.refs.cartBubble.classList.add('cart-bubble--animating');
      // Add shake animation for visual feedback
      this.classList.add('cart-icon--shake');
    }

    // Update the cart count
    const oldCount = this.currentCartCount;
    this.currentCartCount = comingFromProductForm ? oldCount + itemCount : itemCount;

    // Update header state
    this.classList.toggle('header-actions__cart-icon--has-cart', itemCount > 0);

    // Store in session storage for persistence
    sessionStorage.setItem(
      'cart-count',
      JSON.stringify({
        value: String(this.currentCartCount),
        timestamp: Date.now(),
      })
    );

    if (!animate) return;

    // Wait for animations to complete
    await onAnimationEnd(this.refs.cartBubbleText);
    this.refs.cartBubble.classList.remove('cart-bubble--animating');
    
    // Remove shake animation
    setTimeout(() => {
      this.classList.remove('cart-icon--shake');
    }, 500);
  };

  /**
   * Checks if the cart count is correct on page load.
   */
  ensureCartBubbleIsCorrect = () => {
    const sessionStorageCount = sessionStorage.getItem('cart-count');
    const visibleCount = this.refs.cartBubbleCount.textContent;

    if (sessionStorageCount === visibleCount || sessionStorageCount === null) return;

    try {
      const { value, timestamp } = JSON.parse(sessionStorageCount);
      // Only trust session storage if it's less than 10 seconds old
      if (Date.now() - timestamp < 10000) {
        const count = parseInt(value, 10);
        if (count >= 0) {
          this.renderCartBubble(count, false, false);
        }
      }
    } catch (error) {
      console.warn('Failed to parse cart count from session storage:', error);
      sessionStorage.removeItem('cart-count');
    }
  };

  /**
   * Initializes accessibility features.
   */
  initializeAccessibility = () => {
    const button = this.querySelector('button');
    if (!button) return;

    // Update aria-label with current count
    this.updateAriaLabel();
    
    // Add keyboard navigation
    button.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        button.click();
      }
    });
  };

  /**
   * Updates the aria-label with current cart count.
   */
  updateAriaLabel = () => {
    const button = this.querySelector('button');
    if (!button) return;

    const count = this.currentCartCount;
    const label = count === 0 
      ? 'Shopping cart - empty'
      : `Shopping cart - ${count} ${count === 1 ? 'item' : 'items'}`;
    
    button.setAttribute('aria-label', label);
  };

  /**
   * Announces cart updates to screen readers.
   * @param {number} itemCount - The number of items.
   * @param {boolean} comingFromProductForm - Whether it's from product form.
   */
  announceCartUpdate = (itemCount, comingFromProductForm) => {
    const announcement = comingFromProductForm
      ? `${itemCount} ${itemCount === 1 ? 'item' : 'items'} added to cart. Cart now has ${this.currentCartCount} ${this.currentCartCount === 1 ? 'item' : 'items'}.`
      : `Cart updated. Now has ${itemCount} ${itemCount === 1 ? 'item' : 'items'}.`;

    this.announceToScreenReader(announcement);
    this.updateAriaLabel();
  };

  /**
   * Creates a live region announcement for screen readers.
   * @param {string} message - The message to announce.
   */
  announceToScreenReader = (message) => {
    const announcement = document.createElement('div');
    announcement.setAttribute('role', 'status');
    announcement.setAttribute('aria-live', 'polite');
    announcement.classList.add('visually-hidden');
    announcement.textContent = message;

    document.body.appendChild(announcement);

    // Remove after announcement
    setTimeout(() => {
      document.body.removeChild(announcement);
    }, 1000);
  };
}

if (!customElements.get('cart-icon')) {
  customElements.define('cart-icon', CartIcon);
}

// Add CSS for cart icon animations
const style = document.createElement('style');
style.textContent = `
  /* Cart Icon Shake Animation */
  @keyframes cartShake {
    0%, 100% { transform: translateX(0); }
    10%, 30%, 50%, 70%, 90% { transform: translateX(-4px); }
    20%, 40%, 60%, 80% { transform: translateX(4px); }
  }

  .cart-icon--shake {
    animation: cartShake 0.5s ease;
  }

  /* Cart Bubble Pulse Animation */
  @keyframes cartBubblePulse {
    0% {
      transform: scale(1);
    }
    50% {
      transform: scale(1.2);
    }
    100% {
      transform: scale(1);
    }
  }

  .cart-bubble--animating {
    animation: cartBubblePulse 0.4s ease;
  }

  /* Cart Icon Hover Effect */
  cart-icon button {
    transition: all 0.2s ease;
  }

  cart-icon button:hover {
    transform: scale(1.05);
  }

  cart-icon button:active {
    transform: scale(0.95);
  }

  /* Cart Bubble Styling */
  .cart-bubble {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 20px;
    height: 20px;
    padding: 2px 6px;
    border-radius: 10px;
    font-size: 0.75rem;
    font-weight: 600;
    background-color: var(--color-button);
    color: var(--color-button-text);
    line-height: 1;
  }

  .cart-bubble.visually-hidden {
    opacity: 0;
    pointer-events: none;
  }

  /* Accessibility - Focus Visible */
  cart-icon button:focus-visible {
    outline: 2px solid var(--color-foreground);
    outline-offset: 4px;
    border-radius: 4px;
  }
`;
document.head.appendChild(style);